package com.iiht.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.iiht.dao.SkillDAO;
import com.iiht.dao.UserDao;

import com.iiht.model.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.iiht.model.Skill;

@Service("userService")
@Transactional(propagation = Propagation.REQUIRED)
@EnableTransactionManagement
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;

	@Override
	@Transactional
	public void addUser(User user) {
		userDao.addUser(user);
	}

	
	@Override
	public Optional<User> getUserById(Long id) {
		// TODO Auto-generated method stub
		return CrudRepository.findById(id);
	}
	@Override
	@Transactional
	public List<User> getUser() {
		return userDao.getUser();
	}

	@Override
	@Transactional
	public void deleteUser(Long userId) {
		userDao.deleteUser(userId);
	}

	@Override
	@Transactional
	public User editUser(User user) {
		return userDao.editUser(user);
	}

}
