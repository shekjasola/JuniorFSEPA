package com.iiht.dao;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;




import com.iiht.model.User;

import com.iiht.model.Skill;

public interface UserDao extends CrudRepository<User, Long>{

//	public void addUser(User user);

//	public List<User> getUser();

//	public void deleteUser(Long userID);

//	public User editUser(User user);

	
}
