package com.iiht.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.iiht.model.User;
import com.iiht.model.Skill;

public interface UserService {

	public void addUser(User user);
	
	public List<User> getUserById(Long id);

	public List<User> getUsers();

	public void deleteUser(Long userID);

	public User editUser(User user);

}
