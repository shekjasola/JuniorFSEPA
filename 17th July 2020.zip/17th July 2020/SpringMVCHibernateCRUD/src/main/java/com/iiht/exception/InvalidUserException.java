package com.iiht.exception;

import com.iiht.exception.InvalidUserException;

public class InvalidUserException extends RuntimeException {
	public InvalidUserException() {
		super("No such mapskill exists");
	}

}
