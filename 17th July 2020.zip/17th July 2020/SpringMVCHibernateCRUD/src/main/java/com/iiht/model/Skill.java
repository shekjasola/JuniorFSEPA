package com.iiht.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "Skill_TBL")
public class Skill implements Serializable {

	private static final long serialVersionUID = -3465813074586302847L;
	
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int skill_id;

	@Column
	private String task_name;

	@Column
	private String task_satus;

	@Column
	private String task_start_date;

	@Column
	private String task_end_date;

	
	@Column
	private String task_color_code;

	@ManyToOne
	@JoinColumn(name="UserId", nullable=false)
    private User user;
	
	public int getSkill_id() {
		return skill_id;
	}


	public void setskill_id(int task_id) {
		this.skill_id = task_id;
	}


	public String getTask_name() {
		return task_name;
	}


	public void setTask_name(String task_name) {
		this.task_name = task_name;
	}


	public String getTask_satus() {
		return task_satus;
	}


	public void setTask_satus(String task_satus) {
		this.task_satus = task_satus;
	}


	public String getTask_start_date() {
		return task_start_date;
	}


	public void setTask_start_date(String task_start_date) {
		this.task_start_date = task_start_date;
	}


	public String getTask_end_date() {
		return task_end_date;
	}


	public void setTask_end_date(String task_end_date) {
		this.task_end_date = task_end_date;
	}


	public String getTask_color_code() {
		return task_color_code;
	}


	public void setTask_color_code(String task_color_code) {
		this.task_color_code = task_color_code;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	
	@Id
	@Column
	private Long id;
	@Column
	private String skillMinVal;
	@Column
	private String skillMaxVal;
	@Column
	private String begainerLevelMinVal;
	@Column
	private String begainerLevelMaxVal;
	@Column
	private String intermediateLevelMinVal;
	@Column
	private String intermediateLevelMaxVal;
	@Column
	private String expertLevelMinVal;
	@Column
	private String expertLevelMaxVal;
	@Column
	private String remarks;
	@Column
	private String category;
	@Column
	private String type;
	@Column
	private String totalExperience;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSkillMinVal() {
		return skillMinVal;
	}
	public void setSkillMinVal(String skillMinVal) {
		this.skillMinVal = skillMinVal;
	}
	public String getSkillMaxVal() {
		return skillMaxVal;
	}
	public void setSkillMaxVal(String skillMaxVal) {
		this.skillMaxVal = skillMaxVal;
	}
	public String getBegainerLevelMinVal() {
		return begainerLevelMinVal;
	}
	public void setBegainerLevelMinVal(String begainerLevelMinVal) {
		this.begainerLevelMinVal = begainerLevelMinVal;
	}
	public String getBegainerLevelMaxVal() {
		return begainerLevelMaxVal;
	}
	public void setBegainerLevelMaxVal(String begainerLevelMaxVal) {
		this.begainerLevelMaxVal = begainerLevelMaxVal;
	}
	public String getIntermediateLevelMinVal() {
		return intermediateLevelMinVal;
	}
	public void setIntermediateLevelMinVal(String intermediateLevelMinVal) {
		this.intermediateLevelMinVal = intermediateLevelMinVal;
	}
	public String getIntermediateLevelMaxVal() {
		return intermediateLevelMaxVal;
	}
	public void setIntermediateLevelMaxVal(String intermediateLevelMaxVal) {
		this.intermediateLevelMaxVal = intermediateLevelMaxVal;
	}
	public String getExpertLevelMinVal() {
		return expertLevelMinVal;
	}
	public void setExpertLevelMinVal(String expertLevelMinVal) {
		this.expertLevelMinVal = expertLevelMinVal;
	}
	public String getExpertLevelMaxVal() {
		return expertLevelMaxVal;
	}
	public void setExpertLevelMaxVal(String expertLevelMaxVal) {
		this.expertLevelMaxVal = expertLevelMaxVal;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTotalExperience() {
		return totalExperience;
	}
	public void setTotalExperience(String totalExperience) {
		this.totalExperience = totalExperience;
	}
	


	
}