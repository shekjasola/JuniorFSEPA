package com.iiht.exception;
import com.iiht.exception.InvalidUserIdException;

public class InvalidUserIdException extends RuntimeException {
	
	public InvalidUserIdException() {
		super("Invalid UserID ");
	}

}
