package com.iiht.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import org.hibernate.mapping.OneToMany;
import org.hibernate.validator.constraints.NotEmpty;
import javax.persistence.JoinColumn;
import org.hibernate.mapping.OneToMany;
import lombok.Data;

@Entity
@Table(name = "UserMaster")
@Data
//@Document("usermaster")
/*
 * @NoArgsConstructor
 * 
 * @ArgsConstructor(args=)
 * 
 * @ToString
 */
public class User {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UserId")
	private long userId;
	@Column(name = "FirstName")
	private String firstName;
	@Column(name = "LastName")
	private String lastName;
	@Column(name = "Email")
	private String email;
	@Column(name = "MapSkill")
	private String mapSkill;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		email = email;
	}

	public String getMapSkill() {
		return mapSkill;
	}

	public void setMapSkill(String mapSkill) {
		this.mapSkill = mapSkill;
	}

	

}
